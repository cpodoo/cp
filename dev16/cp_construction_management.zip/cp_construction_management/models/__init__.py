# -*- coding: utf-8 -*-

from . import construction_management
from . import account
from . import stock_picking
from . import task
from . import project
from . import note
from . import purchase
from . import product

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# access_material_req_user,cp_construction_management.material_req.user,model_cp_construction_management_material_req,project.group_project_user,1,1,1,1
# access_material_req_line_user,cp_construction_management.material_req_line.user,model_cp_construction_management_material_req_line,project.group_project_user,1,1,1,1
# access_material_conceptions_user,cp_construction_management.material_conceptions.user,model_cp_construction_management_material_conceptions,project.group_project_user,1,1,1,1
