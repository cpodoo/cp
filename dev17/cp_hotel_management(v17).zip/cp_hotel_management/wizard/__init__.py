# -*- coding: utf-8 -*-

from .import room_booking_detail
from .import sale_order_detail
