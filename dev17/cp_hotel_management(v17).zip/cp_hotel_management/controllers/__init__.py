# -*- coding: utf-8 -*-

from . import cp_hotel_management
