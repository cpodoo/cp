# -*- coding: utf-8 -*-

from . import product_product
from . import product_template
from . import purchase_product_history_line
from . import purchase_template_history_line
