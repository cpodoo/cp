# -*- coding: utf-8 -*-
{
    'name': 'Final Price',
    'version': '1.0',
    'summary': 'Control final price visibility on reports',
    'depends': ['sale'],
    'data': [
        'views/sale_order_view.xml',
        'reports/report_saleorder_inherit.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
