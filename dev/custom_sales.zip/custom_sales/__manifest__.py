# -- coding: utf-8 --
{

    'name': 'Custome Sales',
    'version': '18.0.1.0',
    'summary': '',
    'description': '',
    'author': 'Mastermoon Technologies LLP',
    'category': '',
    'depends': ['sale', 'project'],
    'license': 'OPL-1',

    'data': [
        'security/ir.model.access.csv',
        'views/sales_views.xml',
    ],

    'installable': True,
    'application': True,
    'auto_install': False,

}