from odoo import fields, models, api

class CPProductBrand(models.Model):
    _name = 'cp.product.brand'
    _description = 'CP Product Brand'

    name = fields.Char(string="Name", help="Name of the brand", required=True)
    description = fields.Text(string="Description", help="Brand description")
    brand_code = fields.Char(string="Brand Code", readonly=True)
    brand_image = fields.Binary(string="Image", help="Image of the brand", required=True)
    member_ids = fields.One2many('product.template', 'brand_id',
                                 string="Members",
                                 help="Products under the brand")
    product_count = fields.Char(string='Product Count',
                                compute='_compute_product_count', store=True,
                                help="Total number of products in the brand")

    @api.depends('member_ids')
    def _compute_product_count(self):
        for record in self:
            record.product_count = len(record.member_ids)

    @api.model
    def create(self, vals):
        if not vals.get('brand_code'):
            vals['brand_code'] = self.env['ir.sequence'].next_by_code('cp.product.brand') or '/'
        return super(CPProductBrand, self).create(vals)

    stage = fields.Selection([
        ('new', 'New'),
        ('approved', 'Approved'),
        ('cancelled', 'Cancelled'),
    ], string="Stage", default='new', required=True)

    def action_approve(self):
        for rec in self:
            rec.stage = 'approved'

    def action_cancel(self):
        for rec in self:
            rec.stage = 'cancelled'

    sr_no = fields.Integer(string="Sr. No.", compute="_compute_sr_no", store=False)

    def _compute_sr_no(self):
        for idx, record in enumerate(self.sorted('id'), start=1):
            record.sr_no = idx