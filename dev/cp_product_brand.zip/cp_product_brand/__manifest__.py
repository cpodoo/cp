{
    'name': 'CP Product Brand',
    'version': '18.0.1.0.0',
    'category': 'Sales',
    'summary': 'Product Brand in sale for manage products',
    'description': 'This module allows the odoo users to manage their product'
                   ' brands easily',
    'depends': ['stock', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'data/brand_sequence.xml',
        'views/cp_product_brand_views.xml',
        'views/cp_product_template_views.xml',
        'views/sale_report_views.xml',
        'views/product_template_kanban_views.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,

}
