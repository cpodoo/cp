from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class PosOrder(models.Model):
    _inherit = "pos.order"

    order_status = fields.Selection(
        selection=[('pending', 'Pending'), ('inprogress', 'In Progress'), ('done', 'Done')],
        string='Order Status',
        default='pending',
    )

    def _action_confirm(self):
        res = super()._action_confirm()

        for order in self:
            for line in order.lines:
                stock_moves = self.env['stock.move'].search([('pos_order_line_id', '=', line.id)])
                for move in stock_moves:
                    move.cup_size_id = line.cup_size_id.id
                    ingredient_vals = []
                    for ingredient in line.ingredient_ids:
                        ingredient_vals.append((0, 0, {
                            'product_id': ingredient.product_id.id,
                            'quantity': ingredient.quantity,
                            'product_categ_id': ingredient.product_categ_id.id,
                            'product_uom': ingredient.product_uom.id,
                            'stock_move_id': move.id
                        }))
                    move.write({'ingredient_ids': ingredient_vals})

        self._check_warehouse_availability()
        return res

    def _check_warehouse_availability(self):
        StockLocation = self.env['stock.location']
        for order in self:
            warehouse_locations = StockLocation.search([
                ('usage', '=', 'internal'),
                ('active', '=', True)
            ])
            free_location = warehouse_locations.filtered(
                lambda loc: loc.quant_ids.filtered(lambda q: q.quantity == 0)
            )[:1]

            if free_location:
                pickings = self.env['stock.picking'].search([
                    ('origin', '=', order.name),
                    ('state', 'not in', ['done', 'cancel'])
                ])
                if pickings:
                    pickings.write({'location_id': free_location.id})
                    _logger.info(f"POS Order {order.name} assigned to location {free_location.display_name}")

    def update_order_status(self):
        for order in self:
            if order.order_status == 'pending' and any(line.order_line_status == 'inpreparation' for line in order.lines):
                order.order_status = 'inprogress'
            elif order.order_status == 'inprogress' and all(line.order_line_status == 'delivered' for line in order.lines):
                order.order_status = 'done'


class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'

    cup_size_id = fields.Many2one('inventory.product.size', string="Cup Size")
    ingredient_ids = fields.One2many('pos.order.ingredient', 'pos_line_id', string="Ingredients")

    order_line_status = fields.Selection(
        selection=[
            ('pending', 'Pending'),
            ('inpreparation', 'In Preparation'),
            ('delivered', 'Delivered'),
        ],
        string='Status',
        default='inpreparation',
    )

    delivered = fields.Boolean(
        string="Delivered",
        compute='_compute_delivered',
        store=True,
        readonly=False
    )

    @api.depends('order_line_status')
    def _compute_delivered(self):
        for line in self:
            line.delivered = line.order_line_status == 'delivered'


class PosOrderIngredient(models.Model):
    _name = "pos.order.ingredient"
    _description = "POS Order Ingredient"

    pos_line_id = fields.Many2one("pos.order.line", string="POS Order Line")
    stock_move_id = fields.Many2one("stock.move", string="Stock Move")
    product_categ_id = fields.Many2one("product.category", string="Product Category")
    product_id = fields.Many2one("product.template", string="Product")
    quantity = fields.Float(string="Quantity")

    product_uom_category_id = fields.Many2one(
        related='product_id.uom_id.category_id',
        depends=['product_id'],
        store=True
    )

    product_uom = fields.Many2one(
        comodel_name='uom.uom',
        string="Unit of Measure",
        compute='_compute_product_uom',
        store=True,
        domain="[('category_id', '=', product_uom_category_id)]"
    )

    @api.depends('product_id')
    def _compute_product_uom(self):
        for line in self:
            if not line.product_uom or (line.product_id.uom_id.id != line.product_uom.id):
                line.product_uom = line.product_id.uom_id
