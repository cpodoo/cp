# -*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError
from datetime import datetime
from odoo.exceptions import ValidationError



class MaintenanceSchedule(models.Model):
    _name = 'maintenance.schedule.master'
    _description = 'Maintenance Schedule Master'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Name", required=True)
    asset_type_id = fields.Many2one('asset.type', string="Asset Type")
    frequency = fields.Integer(string="Frequency")
    frequency_type = fields.Selection([('daily','Daily'),('week', 'Week'), ('month', 'Month'), ('year', 'Year')])
    reading = fields.Integer(string="Reading")
    checklist_ids = fields.One2many('maintenance.task.line', 'maintenance_id', string="Checklist")
    inspection_checklist_ids = fields.One2many('inspection.checklist.line', 'maintenance_schedule_id', string="Inspection Checklist")

class MaintenanceTaskLine(models.Model):
    _name = 'maintenance.task.line'
    _description = 'Maintenance Checklist Line'
    _order = 'sequence, id'

    maintenance_id = fields.Many2one(
        'maintenance.schedule.master', string="Schedule", ondelete='cascade'
    )
    sequence = fields.Integer(string="Sequence", default=10)
    display_type = fields.Selection([
        ('line_section', 'Section'),
        ('line_note',    'Note'),
    ], default=False, help="Technical field for sections & notes")

    # This is the title for sections/notes, and the description for normal lines
    name = fields.Char("Description", required=True)
    maintenance_order_id = fields.Many2one('maintenance.order')
    product_name = fields.Char("Product Name/Item")
    product_id = fields.Many2one("product.template", string="Product")
    # product_type = fields.Selection(
    #     string="Product Type",
    #     selection=[
    #         ('consu', "Goods"),
    #         ('service', "Service"),
    #         ('combo', "Combo"),
    #     ],
    # )
    activity     = fields.Selection([
        ('repair',  'Repair'),
        ('replace', 'Replace'),
        ('check',   'Check'),
    ], string="Activity")

    # SQL constraints to enforce normal‐vs‐section logic:
    _sql_constraints = [
        ('accountable_required_fields',
         "CHECK(display_type IS NOT NULL OR (product_id IS NOT NULL AND activity IS NOT NULL))",
         "Product Name & Activity are required for normal checklist lines."),
        ('non_accountable_null_fields',
         "CHECK(display_type IS NULL OR (product_id IS NULL AND activity IS NULL))",
         "Sections/Notes cannot have Product Name or Activity."),
    ]

    uom_id = fields.Many2one('uom.uom', related='product_id.uom_id', string='Unit of Measurement', store=True, readonly=True)
    quantity = fields.Float(string='Quantity')
    status = fields.Selection([
        ('low', 'Low'),
        ('normal', 'Normal'),
        ('high', 'High'),
    ], string='Status', store=True)
    text_value = fields.Char(string="Remarks")
    employee_name = fields.Char(string='Done By')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('display_type'):
                vals.update(product_id=False, activity=False)
        return super().create(vals_list)

    def write(self, vals):
        # Prevent changing a line’s type after creation
        if 'display_type' in vals:
            for line in self:
                if line.display_type != vals['display_type']:
                    raise UserError(_("You cannot change the type of a checklist line. Delete and recreate."))
        return super().write(vals)
