from odoo import models, fields,api
from dateutil.relativedelta import relativedelta


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        res = super().button_validate()

        for picking in self:
            for move in picking.move_ids:
                if move.product_id.is_asset:
                    for move_line in move.move_line_ids:
                        product = move.product_id
                        lot = move_line.lot_id
                        asset_name = move_line.lot_name
                        category = product.categ_id
                        purchase_date = picking.purchase_id.date_approve
                        purchase_name = picking.origin
                        purchase_id = self.env['purchase.order'].search([('name', '=', purchase_name)], limit=1)

                        asset = self.env['account.asset'].create({
                            'name': asset_name,
                            'serial_number_id': lot.id,
                            'purchase_date': purchase_date,
                            'original_value': product.standard_price
                        })

                        self.env['asset.asset'].create({
                            'name': asset_name + " - " + product.asset_type_id.name,
                            'category_id': category.id,
                            'serial_number_id': lot.id,
                            'asset_type_id': product.asset_type_id.id,
                            'purchase_date': purchase_date,
                            'purchase_id': purchase_id.id,
                        })

        return res

