# -*- coding: utf-8 -*-

from . import asset
from . import stock_picking
from . import inspection_master
from . import maintenance_master
from . import product_template
from . import account_asset
from . import point_of_sale
from . import maintenance_order
from . import inspection_order

