# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, time

class ChaiAssetType(models.Model):
    _name = 'asset.type'
    _description = 'Asset Type'

    name = fields.Char(string='Name', required=True)

class AssetAsset(models.Model):
    _name = 'asset.asset'
    _description = 'Asset'

    name = fields.Char(string="Name", required=True)
    category_id = fields.Many2one('product.category', string="Category")
    asset_type_id = fields.Many2one('asset.type', string="Asset Type")
    manufacturing_date = fields.Date(string="Manufacturing Date")
    serial_no = fields.Char(string="Unique Serial No")
    serial_number_id = fields.Many2one('stock.lot', 'Serial Number')

    document_ids = fields.One2many('asset.document', 'asset_id', string="Documents")
    purchase_id = fields.Many2one('purchase.order', string="Purchase Order")
    purchase_date = fields.Date(string="Purchase Date", store=True)
    app_id = fields.Char(string='App Id')

    inspection_ids = fields.One2many('inspection.order', 'asset_id', string="Inspections")
    maintenance_ids = fields.One2many('maintenance.order', 'asset_id', string="Maintenance")
    location_id = fields.Many2one('stock.location', string="Location")

class AssetDocument(models.Model):
    _name = 'asset.document'
    _description = 'Asset Document'

    asset_id = fields.Many2one('asset.asset', string="Asset")
    name = fields.Char(string="Document Name")
    document_date = fields.Date(string="Document Date")
    expiry_date = fields.Date(string="Expiry Date")
    certificate = fields.Binary(string="Certificate Attachment")




	





