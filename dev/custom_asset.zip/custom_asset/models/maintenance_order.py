from odoo import models, fields, api
from datetime import datetime


class MaintenanceOrder(models.Model):
    _name = 'maintenance.order'
    _description = 'Maintenance Order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'maintenance_order_no desc'

    # Main Fields
    maintenance_order_no = fields.Char(
        string='Maintenance Order No',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: self.env['ir.sequence'].next_by_code('maintenance.order') or 'New'
    )

    asset_id = fields.Many2one('asset.asset', string="Asset")

    asset_type_id = fields.Many2one(
        'asset.type',
        string='Asset Type',
        required=True,
        tracking=True
    )

    asset_name_id = fields.Many2one(
        'asset.asset',
        string='Asset Name',
        required=True,
        tracking=True
    )

    asset_serial_no = fields.Char(
        related='asset_name_id.serial_no',
        string='Asset Serial No',
        readonly=True
    )

    current_location = fields.Char(
        string='Current Location',
        help='Taken from inventory as per current warehouse name'
    )

    warehouse_id = fields.Many2one(
        'stock.warehouse',
        string='Warehouse',
        tracking=True
    )

    # warehouse_address = fields.Char(
    #     related='warehouse_id.partner_id.contact_address_complete',
    #     string='Warehouse Address',
    #     readonly=True
    # )

    current_reading = fields.Integer(
        string='Current Reading',
        tracking=True
    )

    scheduled_date = fields.Date(
        string='Scheduled Date',
        required=True,
        tracking=True
    )

    assigned_to = fields.Many2one(
        'hr.employee',
        string='Assigned To',
        required=True,
        tracking=True
    )

    owner_id = fields.Many2one(
        'res.users',
        string='Owner',
        default=lambda self: self.env.user,
        tracking=True
    )

    planned_date = fields.Date(
        string='Planned Date',
        tracking=True
    )

    actual_date = fields.Date(
        string='Actual Date',
        tracking=True
    )

    maintenance_master_id = fields.Many2one(
        'maintenance.schedule.master',
        string='Maintenance Master',
        required=True
    )

    # Priority
    priority = fields.Selection([
        ('low', 'Low'),
        ('normal', 'Normal'),
        ('high', 'High'),
        ('urgent', 'Urgent')
    ], string='Priority', default='normal', tracking=True)

    # Maintenance Type
    maintenance_type = fields.Selection([
        ('preventive', 'Preventive'),
        ('corrective', 'Corrective'),
        ('emergency', 'Emergency')
    ], string='Maintenance Type', default='preventive', tracking=True)

    # Cost Information
    estimated_cost = fields.Float(
        string='Estimated Cost',
        tracking=True
    )

    actual_cost = fields.Float(
        string='Actual Cost',
        tracking=True
    )

    # Remarks and Findings
    remarks_note = fields.Html(
        string='Remarks and Findings',
        help='Detailed notes about the maintenance'
    )

    # Task List
    task_ids = fields.One2many(
        'maintenance.task.line',
        'maintenance_order_id',
        string='Tasks'
    )
    inspection_check_ids = fields.One2many(
        'inspection.checklist.line',
        'inspection_check_order_id',
        string='Inspection Checklist'
    )

    # Stage
    stage = fields.Selection([
        ('draft', 'Draft'),
        ('scheduled', 'Scheduled'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled')
    ], string='Stage', default='draft', tracking=True)

    # Computed Fields
    task_count = fields.Integer(
        string='Task Count',
        compute='_compute_task_count'
    )

    # completion_percentage = fields.Float(
    #     string='Completion %',
    #     compute='_compute_completion_percentage'
    # )
    #
    # @api.depends('task_ids')
    # def _compute_task_count(self):
    #     for record in self:
    #         record.task_count = len(record.task_ids)

    # @api.depends('task_ids.status')
    # def _compute_completion_percentage(self):
    #     for record in self:
    #         if record.task_ids:
    #             completed_tasks = record.task_ids.filtered(lambda t: t.status == 'completed')
    #             record.completion_percentage = (len(completed_tasks) / len(record.task_ids)) * 100
    #         else:
    #             record.completion_percentage = 0.0

    @api.model
    def create(self, vals):
        if vals.get('maintenance_order_no', 'New') == 'New':
            vals['maintenance_order_no'] = self.env['ir.sequence'].next_by_code('maintenance.order') or 'New'
        return super(MaintenanceOrder, self).create(vals)

    def action_schedule(self):
        self.stage = 'scheduled'

    def action_start_maintenance(self):
        self.stage = 'in_progress'
        self.actual_date = fields.Date.today()

    def action_complete_maintenance(self):
        self.stage = 'completed'

    def action_cancel_maintenance(self):
        self.stage = 'cancelled'

    @api.onchange('maintenance_master_id')
    def onchange_maintenance_master(self):
        if not self.maintenance_master_id:
            return

        # Clear existing lines
        self.update({
            'task_ids': [(5, 0, 0)],
            'inspection_check_ids': [(5, 0, 0)],
        })

        # 1. Load Tasks (assuming One2many 'task_ids' on master)
        for task in self.maintenance_master_id.checklist_ids:
            self.task_ids = [(0, 0, {
                'product_id' : task.product_id.id,
                'name': task.name,
                'activity': task.activity
            })]

        # 2. Load Inspection Checklist (assuming One2many 'checklist_ids' on master)
        for item in self.maintenance_master_id.inspection_checklist_ids:
            self.inspection_check_ids += [(0, 0, {
                'name': item.name,
                'selection_type': item.selection_type,
                'selection_value_ids': [(6, 0, item.selection_value_ids.ids)],
            })]


class MaintenanceTask(models.Model):
    _name = 'maintenance.task'
    _description = 'Maintenance Task'
    _order = 'sequence, id'

    maintenance_order_id = fields.Many2one(
        'maintenance.order',
        string='Maintenance Order',
        required=True,
        ondelete='cascade'
    )

    sequence = fields.Integer(
        string='Sequence',
        default=10
    )

    name = fields.Char(
        string='Task Name',
        required=True
    )

    description = fields.Text(
        string='Description'
    )

    product_id = fields.Many2one(
        'product.product',
        string='Product/Part'
    )

    quantity = fields.Float(
        string='Quantity',
        default=1.0
    )

    activity_type = fields.Selection([
        ('repair', 'Repair'),
        ('replace', 'Replace'),
        ('check', 'Check'),
        ('clean', 'Clean'),
        ('lubricate', 'Lubricate')
    ], string='Activity Type', required=True)

    status = fields.Selection([
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled')
    ], string='Status', default='pending')

    assigned_to = fields.Many2one(
        'hr.employee',
        string='Assigned To'
    )

    estimated_hours = fields.Float(
        string='Estimated Hours'
    )

    actual_hours = fields.Float(
        string='Actual Hours'
    )

    remarks = fields.Text(
        string='Remarks'
    )

    def action_start_task(self):
        self.status = 'in_progress'

    def action_complete_task(self):
        self.status = 'completed'

    def action_cancel_task(self):
        self.status = 'cancelled'