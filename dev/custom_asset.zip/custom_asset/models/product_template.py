# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_asset = fields.Boolean(string='Is Asset')
    asset_type_id = fields.Many2one('asset.type', string='Asset Type')