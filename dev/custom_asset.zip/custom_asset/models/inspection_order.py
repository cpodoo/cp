from odoo import models, fields, api
from datetime import datetime


class InspectionOrder(models.Model):
    _name = 'inspection.order'
    _description = 'Inspection Order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'inspection_order_no desc'

    # Main Fields
    inspection_order_no = fields.Char(
        string='Inspection Order No',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: self.env['ir.sequence'].next_by_code('inspection.order') or 'New'
    )

    asset_id = fields.Many2one('asset.asset', string="Asset")

    asset_type_id = fields.Many2one(
        'asset.type',
        string='Asset Type',
        required=True,
        tracking=True
    )

    asset_name_id = fields.Many2one(
        'asset.asset',
        string='Asset Name',
        required=True,
        tracking=True
    )

    asset_serial_no = fields.Char(
        related='asset_name_id.serial_no',
        string='Asset Serial No',
        readonly=True
    )

    current_location = fields.Char(
        string='Current Location',
        help='Taken from inventory as per current warehouse name'
    )

    warehouse_id = fields.Many2one(
        'stock.warehouse',
        string='Warehouse',
        tracking=True
    )

    warehouse_address = fields.Char(
        related='warehouse_id.partner_id.contact_address_complete',
        string='Warehouse Address',
        readonly=True
    )

    current_reading = fields.Integer(
        string='Current Reading',
        tracking=True
    )

    scheduled_date = fields.Date(
        string='Scheduled Date',
        required=True,
        tracking=True
    )

    assigned_to = fields.Many2one(
        'hr.employee',
        string='Assigned To',
        required=True,
        tracking=True
    )

    owner_id = fields.Many2one(
        'res.users',
        string='Owner',
        default=lambda self: self.env.user,
        tracking=True
    )

    planned_date = fields.Date(
        string='Planned Date',
        tracking=True
    )

    actual_date = fields.Date(
        string='Actual Date',
        tracking=True
    )

    inspection_master_id = fields.Many2one(
        'inspection.schedule.master',
        string='Inspection Master',
        required=True
    )

    # Remarks and Findings
    remarks_note = fields.Html(
        string='Remarks and Findings',
        help='Detailed notes about the inspection'
    )

    task_ids = fields.One2many('inspection.checklist.line', 'inspection_order_id', string="Tasks")

    # Stage
    stage = fields.Selection([
        ('draft', 'Draft'),
        ('scheduled', 'Scheduled'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled')
    ], string='Stage', default='draft', tracking=True)

    # Computed Fields
    # task_count = fields.Integer(
    #     string='Task Count',
    #     compute='_compute_task_count'
    # )

    # completion_percentage = fields.Float(
    #     string='Completion %',
    #     compute='_compute_completion_percentage'
    # )

    # @api.depends('task_ids')
    # def _compute_task_count(self):
    #     for record in self:
    #         record.task_count = len(record.task_ids)

    # @api.depends('task_ids.status')
    # def _compute_completion_percentage(self):
    #     for record in self:
    #         if record.task_ids:
    #             completed_tasks = record.task_ids.filtered(lambda t: t.status == 'completed')
    #             record.completion_percentage = (len(completed_tasks) / len(record.task_ids)) * 100
    #         else:
    #             record.completion_percentage = 0.0

    @api.model
    def create(self, vals):
        if vals.get('inspection_order_no', 'New') == 'New':
            vals['inspection_order_no'] = self.env['ir.sequence'].next_by_code('inspection.order') or 'New'
        return super(InspectionOrder, self).create(vals)

    def action_schedule(self):
        self.stage = 'scheduled'

    def action_start_inspection(self):
        self.stage = 'in_progress'
        self.actual_date = fields.Date.today()

    def action_complete_inspection(self):
        self.stage = 'completed'

    def action_cancel_inspection(self):
        self.stage = 'cancelled'

    @api.onchange('inspection_master_id')
    def onchange_order_line(self):
        if self.inspection_master_id:
            self.task_ids = [(5, 0, 0)]  # Clear existing lines
            check_list_items = self.inspection_master_id.checklist_ids
            order_lines = []
            for check_item in check_list_items:
                order_lines.append((0, 0, {
                    'name': check_item.name,
                    'selection_type': check_item.selection_type,
                    'selection_value_ids': [(6, 0, check_item.selection_value_ids.ids)]
                    # Add other fields you want to populate from inspection_master_id
                    # 'activity_name': check_item.activity_name,
                    # 'description': check_item.description,
                }))
            self.task_ids = order_lines
