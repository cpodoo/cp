# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError

class InspectionSchedule(models.Model):
    _name = 'inspection.schedule.master'
    _description = 'Inspection Schedule Master'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Name", required=True)
    asset_type_id = fields.Many2one('asset.type', string="Asset Type")
    frequency = fields.Integer(string="Frequency")
    frequency_type = fields.Selection([('daily','Daily'),('week', 'Week'), ('month', 'Month'), ('year', 'Year')])
    reading = fields.Integer(string="Reading")
    checklist_ids = fields.One2many('inspection.checklist.line', 'schedule_id', string="Checklist")


class InspectionChecklistLine(models.Model):
    _name = 'inspection.checklist.line'
    _description = 'Inspection Checklist Line'
    _order = 'sequence, id'

    maintenance_schedule_id = fields.Many2one('maintenance.schedule.master', string='Inspection Master')
    schedule_id = fields.Many2one('inspection.schedule.master', string="Schedule",ondelete='cascade')
    task_name = fields.Char(string="Task Name")
    sequence = fields.Integer(string="Sequence", default=10)

    display_type = fields.Selection([
        ('line_section', 'Section'),
        ('line_note', 'Note'),
    ], default=False, help="Technical field for sections & notes")

    name = fields.Char("Task Name")
    inspection_order_id = fields.Many2one('inspection.order')
    # Selection type field to determine whether to show dropdown or text field
    selection_type = fields.Selection([
        ('selection', 'Selection'),
        ('text', 'Text')
    ], string="Selection Type", help="Yes for dropdown, No for text field")

    # Dropdown field (shown when selection_type is 'yes')
    selection_values = fields.Selection([
        ('ok', 'OK'),
        ('not_ok', 'Not OK'),
        ('na', 'N/A'),
    ], string="Optional Values")
    selection_value_ids = fields.Many2many(
        'custom.selection.value',
        string="Optional Values")
    # optional_values = fields.Many2one('optional.values')
    asset_type_id = fields.Many2many('asset.type', string="Asset Type")


    # Text field (shown when selection_type is 'no')
    text_value = fields.Char(string="Remarks")
    selected_value_id = fields.Many2one('custom.selection.value', string='Optional Values')
    _sql_constraints = [
        ('accountable_required_fields',
         "CHECK(display_type IS NOT NULL OR (name IS NOT NULL AND selection_type IS NOT NULL))",
         "Task Name & Result Type are required for normal checklist lines."),
        ('non_accountable_null_fields',
         "CHECK(display_type IS NULL OR (name IS NULL AND selection_type IS NULL))",
         "Sections/Notes cannot have Task Name or Result."),
    ]

    inspection_check_order_id = fields.Many2one('maintenance.order')

    # @api.onchange('selection_value_ids')
    # def _onchange_selection_value_ids(self):
    #     return {
    #         'domain': {
    #             'selected_value_id': [('id', 'in', self.selection_value_ids.ids)]
    #         }
    #     }

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('display_type'):
                # clear out normal‑line fields on sections/notes
                vals.update(task_name=False, selection_value_ids=False, selection_type=False)
        return super().create(vals_list)

    def write(self, vals):
        if 'display_type' in vals:
            for line in self:
                if line.display_type != vals['display_type']:
                    raise UserError(_("You cannot change the type of a checklist line. Delete and recreate."))
        return super().write(vals)

    class CustomSelectionValue(models.Model):
        _name = 'custom.selection.value'
        _description = 'Custom Selection Values'

        name = fields.Char(string="Value", required=True)
