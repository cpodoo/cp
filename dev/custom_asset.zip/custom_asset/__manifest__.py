# -*- coding: utf-8 -*-
{
    'name': 'Asset Customization',
    'version': '1.0',
    'depends': ['base', 'stock','purchase','product','account_asset','point_of_sale'],
    'author': '',
    'category': 'Asset',
    'description': 'Manage company assets with serial tracking and purchase linking',
    'data': [
        'security/ir.model.access.csv',
        'views/asset_views.xml',
        'views/account_asset_inherit.xml',
        'views/inspection_master.xml',
        'views/maintenance_master.xml',
        'views/product_template.xml',
        'views/pos_views.xml',
        'views/maintenance_order_views.xml',
        'views/inspection_order_views.xml',
        
    ],
    'installable': True,
    'application': True,
}
